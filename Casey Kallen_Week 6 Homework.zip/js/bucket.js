$( "#accordion" ).accordion();


$('#accordion').accordion({heightStyle: 'content'});
